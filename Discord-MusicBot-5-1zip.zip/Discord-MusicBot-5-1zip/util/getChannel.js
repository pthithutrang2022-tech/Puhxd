module.exports = async (client, interaction) => {
  return new Promise(async (resolve) => {
    if (!interaction.member.voice.channel) {
      await interaction.reply({
        embeds: [client.ErrorEmbed("Bạn phải ở trong kênh thoại để dùng lệnh này!")],
      });
      return resolve(false);
    }
    if (
      interaction.guild.members.me.voice.channel &&
      interaction.member.voice.channel.id !==
        interaction.guild.members.me.voice.channel.id
    ) {
      await interaction.reply({
        embeds: [client.ErrorEmbed("Bạn phải ở cùng kênh thoại với tôi!")],
      });
      return resolve(false);
    }
    if (!interaction.member.voice.channel.joinable) {
      await interaction.reply({
        embeds: [client.ErrorEmbed("Tôi không có đủ quyền để tham gia kênh thoại của bạn!")],
      });
      return resolve(false);
    }
    resolve(interaction.member.voice.channel);
  });
};
