const { MessageEmbed } = require("discord.js");

module.exports = async (client, interaction) => {
  const guild = client.guilds.cache.get(interaction.customId.split(":")[1]);
  const property = interaction.customId.split(":")[2];
  const player = client.manager.get(guild.id);

  if (!player) {
    await interaction.reply({
      embeds: [client.Embed("❌ | **Không có player nào đang hoạt động trong máy chủ này.**")],
    });
    setTimeout(() => interaction.deleteReply().catch(() => {}), 5000);
    return;
  }

  if (!interaction.member.voice.channel) {
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("❌ | **Bạn phải ở trong kênh thoại để dùng tính năng này!**"),
      ],
      ephemeral: true,
    });
  }

  if (
    interaction.guild.members.me.voice.channel &&
    !interaction.guild.members.me.voice.channel.equals(interaction.member.voice.channel)
  ) {
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("❌ | **Bạn phải ở cùng kênh thoại với tôi!**"),
      ],
      ephemeral: true,
    });
  }

  if (property === "Stop") {
    player.queue.clear();
    player.stop();
    player.set("autoQueue", false);
    client.warn(`Player: ${player.options.guild} | Đã dừng player thành công`);
    const msg = await interaction.channel.send({
      embeds: [client.Embed("⏹️ | **Đã dừng phát nhạc thành công**")],
    }).catch(() => {});
    if (msg) setTimeout(() => msg.delete().catch(() => {}), 5000);
    interaction.update({
      components: [client.createController(player.options.guild, player)],
    }).catch(() => {});
    return;
  }

  if (property === "Replay") {
    const previousSong = player.queue.previous;
    const currentSong = player.queue.current;
    const nextSong = player.queue[0];
    if (
      !previousSong ||
      previousSong === currentSong ||
      previousSong === nextSong
    ) {
      return interaction.reply({
        ephemeral: true,
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Không có bài hát nào trước đó."),
        ],
      });
    }
    if (previousSong !== currentSong && previousSong !== nextSong) {
      player.queue.splice(0, 0, currentSong);
      player.play(previousSong);
      return interaction.deferUpdate().catch(() => {});
    }
  }

  if (property === "PlayAndPause") {
    if (!player || (!player.playing && player.queue.totalSize === 0)) {
      const msg = await interaction.channel.send({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Hiện không có bài hát nào đang phát."),
        ],
      }).catch(() => {});
      if (msg) setTimeout(() => msg.delete().catch(() => {}), 5000);
      return interaction.deferUpdate().catch(() => {});
    }
    player.pause(!player.paused);
    client.warn(
      `Player: ${player.options.guild} | Đã ${player.paused ? "tạm dừng" : "tiếp tục"} player`
    );
    return interaction.update({
      components: [client.createController(player.options.guild, player)],
    }).catch(() => {});
  }

  if (property === "Next") {
    const song = player.queue.current;
    const autoQueue = player.get("autoQueue");
    if (player.queue[0] == undefined && (!autoQueue || autoQueue === false)) {
      return interaction.reply({
        ephemeral: true,
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription(
              `Không còn bài nào sau [${song.title}](${song.uri}) trong hàng chờ.`
            ),
        ],
      });
    }
    player.stop();
    return interaction.deferUpdate().catch(() => {});
  }

  if (property === "Loop") {
    if (player.trackRepeat) {
      player.setTrackRepeat(false);
      player.setQueueRepeat(true);
    } else if (player.queueRepeat) {
      player.setQueueRepeat(false);
    } else {
      player.setTrackRepeat(true);
    }
    client.warn(
      `Player: ${player.options.guild} | Chế độ lặp: ${
        player.trackRepeat ? "lặp bài" : player.queueRepeat ? "lặp hàng chờ" : "tắt"
      }`
    );
    interaction.update({
      components: [client.createController(player.options.guild, player)],
    }).catch(() => {});
    return;
  }

  return interaction.reply({
    ephemeral: true,
    content: "❌ | **Tùy chọn controller không hợp lệ**",
  });
};
