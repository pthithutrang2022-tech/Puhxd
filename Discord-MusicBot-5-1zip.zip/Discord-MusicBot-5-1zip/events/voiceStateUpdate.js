const { MessageEmbed } = require("discord.js");

module.exports = async (client, oldState, newState) => {
  const guildId = newState.guild.id;
  const player = client.manager.get(guildId);

  if (!player || player.state !== "CONNECTED") return;

  const stateChange = {};
  if (oldState.channel === null && newState.channel !== null) stateChange.type = "JOIN";
  if (oldState.channel !== null && newState.channel === null) stateChange.type = "LEAVE";
  if (oldState.channel !== null && newState.channel !== null) stateChange.type = "MOVE";
  if (oldState.channel === null && newState.channel === null) return;

  if (newState.serverMute === true && oldState.serverMute === false && newState.id === client.config.clientId) {
    return player.pause(true);
  }
  if (newState.serverMute === false && oldState.serverMute === true && newState.id === client.config.clientId) {
    return player.pause(false);
  }

  if (stateChange.type === "MOVE") {
    if (oldState.channel.id === player.voiceChannel) stateChange.type = "LEAVE";
    if (newState.channel.id === player.voiceChannel) stateChange.type = "JOIN";
  }

  if (stateChange.type === "JOIN") stateChange.channel = newState.channel;
  if (stateChange.type === "LEAVE") stateChange.channel = oldState.channel;

  if (!stateChange.channel || stateChange.channel.id !== player.voiceChannel) return;

  player.prevMembers = player.members;
  player.members = stateChange.channel.members.filter((m) => !m.user.bot).size;

  const textCh = client.channels.cache.get(player.textChannel);

  switch (stateChange.type) {
    case "JOIN":
      if (player.get("autoPause") === true) {
        const members = stateChange.channel.members.filter((m) => !m.user.bot).size;
        if (members === 1 && player.paused && members !== player.prevMembers) {
          player.pause(false);
          if (textCh) {
            const resumeMsg = await textCh.send({
              embeds: [
                new MessageEmbed()
                  .setColor(client.config.embedColor)
                  .setTitle("Đã tiếp tục!")
                  .setDescription(`Đang phát [${player.queue.current.title}](${player.queue.current.uri})`)
                  .setFooter({ text: "Bài hát hiện tại đã được tiếp tục." }),
              ],
            }).catch(() => {});
            if (resumeMsg) {
              player.setResumeMessage(client, resumeMsg);
              setTimeout(() => {
                if (!client.isMessageDeleted(resumeMsg)) {
                  resumeMsg.delete().catch(() => {});
                  client.markMessageAsDeleted(resumeMsg);
                }
              }, 5000);
            }
          }
        }
      }
      break;

    case "LEAVE": {
      const members = stateChange.channel.members.filter((m) => !m.user.bot).size;
      const twentyFourSeven = player.get("twentyFourSeven");
      const autoPause = player.get("autoPause");
      const autoLeave = player.get("autoLeave");

      const sendDisconnectedEmbed = async () => {
        if (!textCh) return null;
        const embed = new MessageEmbed()
          .setColor(client.config.embedColor)
          .setAuthor({ name: "Đã ngắt kết nối!", iconURL: client.config.iconURL })
          .setFooter({ text: "Rời đi vì không còn ai trong kênh thoại." })
          .setTimestamp();
        const msg = await textCh.send({ embeds: [embed] }).catch(() => {});
        if (msg) setTimeout(() => msg.delete().catch(() => {}), 5000);
        return msg;
      };

      if (autoPause === true && autoLeave === false) {
        if (members === 0 && !player.paused && player.playing) {
          player.pause(true);
          if (textCh) {
            const pausedMsg = await textCh.send({
              embeds: [
                new MessageEmbed()
                  .setColor(client.config.embedColor)
                  .setTitle("Đã tạm dừng!")
                  .setFooter({ text: "Bài hát đã tạm dừng vì không còn ai trong kênh thoại." }),
              ],
            }).catch(() => {});
            if (pausedMsg) player.setPausedMessage(client, pausedMsg);
          }
        }
      } else if (autoLeave === true && autoPause === false) {
        if (members === 0) {
          if (twentyFourSeven) {
            setTimeout(async () => {
              const currentMembers = stateChange.channel.members.filter((m) => !m.user.bot).size;
              if (currentMembers === 0 && player.state !== "DISCONNECTED") {
                await sendDisconnectedEmbed();
                player.queue.clear();
                player.destroy();
                player.set("autoQueue", false);
              }
            }, client.config.disconnectTime);
          } else {
            await sendDisconnectedEmbed();
            player.destroy();
          }
        }
      } else if (autoLeave === true && autoPause === true) {
        if (members === 0 && !player.paused && player.playing && twentyFourSeven) {
          player.pause(true);
          if (textCh) {
            const pausedMsg = await textCh.send({
              embeds: [
                new MessageEmbed()
                  .setColor(client.config.embedColor)
                  .setTitle("Đã tạm dừng!")
                  .setFooter({ text: "Bài hát đã tạm dừng vì không còn ai trong kênh thoại." }),
              ],
            }).catch(() => {});
            if (pausedMsg) player.setPausedMessage(client, pausedMsg);
          }
          setTimeout(async () => {
            const currentMembers = stateChange.channel.members.filter((m) => !m.user.bot).size;
            if (currentMembers === 0 && player.state !== "DISCONNECTED") {
              await sendDisconnectedEmbed();
              player.queue.clear();
              player.destroy();
              player.set("autoQueue", false);
            }
          }, client.config.disconnectTime);
        } else if (members === 0 && player.state !== "DISCONNECTED") {
          await sendDisconnectedEmbed();
          player.destroy();
        }
      }
      break;
    }
  }
};
