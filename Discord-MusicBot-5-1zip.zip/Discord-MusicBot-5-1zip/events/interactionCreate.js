const Controller = require("../util/Controller");
const yt = require("youtube-sr").default;

module.exports = async (client, interaction) => {
  if (interaction.isCommand()) {
    const command = client.slashCommands.find(
      (x) => x.name == interaction.commandName
    );
    if (!command || !command.run) {
      return interaction.reply("Lệnh này không có chức năng thực thi.");
    }
    client.commandsRan++;
    command.run(client, interaction, interaction.options);
    return;
  }

  if (interaction.isContextMenu()) {
    const command = client.contextCommands.find(
      (x) => x.command.name == interaction.commandName
    );
    if (!command || !command.run) {
      return interaction.reply("Lệnh này không có chức năng thực thi.");
    }
    client.commandsRan++;
    command.run(client, interaction, interaction.options);
    return;
  }

  if (interaction.isButton()) {
    if (interaction.customId.startsWith("controller")) {
      Controller(client, interaction);
    }
  }

  if (interaction.isAutocomplete()) {
    const url = interaction.options.getString("query");
    if (!url) return;

    const isUrl = [
      /^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu\.be))(\/(?:[\w-]+\?v=|embed\/|v\/)?)([\w-]+)(\S+)?$/,
      /^https?:\/\/(?:www\.)?soundcloud\.com\/(.*)$/,
      /^https?:\/\/(?:www\.)?deezer\.com\/[a-z]+\/(track|album|playlist)\/(\d+)$/,
      /(?:https:\/\/music\.apple\.com\/)(?:.+)?(artist|album|music-video|playlist)\/([\w.-]+(\/)+[\w.-]+|[^&]+)\/([\w.-]+(\/)+[\w.-]+|[^&]+)/,
      /^https?:\/\/(?:www\.)?bandcamp\.com\/(.*)$/,
      /^https?:\/\/(?:[a-z]+\.)?bandcamp\.com\//,
      /^https?:\/\/(?:www\.)?vimeo\.com\/(\d+)/,
      /^https?:\/\/(?:www\.)?twitch\.tv\/(.+)/,
      /^https?:\/\/.+\.(mp3|mp4|m3u8|ogg|flac|wav|aac|webm|opus)(\?.*)?$/i,
      /^https?:\/\/.+$/,
    ].some((re) => re.test(url));

    if (interaction.commandName === "phat") {
      if (isUrl) {
        return interaction.respond([{ name: url, value: url }]).catch(() => {});
      }

      try {
        const results = await yt.search(url || "nhạc hay", {
          safeSearch: false,
          limit: 25,
        });
        const choices = results.map((x) => ({
          name: (x.title || "Không có tiêu đề").slice(0, 100),
          value: x.url,
        }));
        return interaction.respond(choices).catch(() => {});
      } catch {
        return interaction.respond([]).catch(() => {});
      }
    }
  }
};
