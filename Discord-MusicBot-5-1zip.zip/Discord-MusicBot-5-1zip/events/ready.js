module.exports = (client) => {
  client.manager.init(client.user.id);
  client.user.setPresence(client.config.presence);
  client.log("Đã đăng nhập thành công với tài khoản " + client.user.tag);
};
