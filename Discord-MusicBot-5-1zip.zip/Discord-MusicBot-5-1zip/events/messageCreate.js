const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");

module.exports = async (client, message) => {
  if (message.author.bot) return;

  const refront = `^<@!?${client.user.id}>`;
  const mention = new RegExp(refront + "$");

  const invite = `https://discord.com/oauth2/authorize?client_id=${
    client.config.clientId
  }&permissions=${client.config.permissions}&scope=${client.config.inviteScopes
    .toString()
    .replace(/,/g, "%20")}`;

  const buttons = new MessageActionRow().addComponents(
    new MessageButton().setStyle("LINK").setLabel("Mời bot").setURL(invite),
    new MessageButton()
      .setStyle("LINK")
      .setLabel("Máy chủ hỗ trợ")
      .setURL(`${client.config.supportServer}`)
  );

  if (message.content.match(mention)) {
    const mentionEmbed = new MessageEmbed()
      .setColor(client.config.embedColor)
      .setDescription(
        `Tiền tố của tôi trên máy chủ này là \`/\` (Lệnh Slash).\nGõ \`/tro-giup\` để xem tất cả lệnh của tôi.\nNếu không thấy lệnh, hãy [mời lại](${invite}) tôi với đủ quyền.`
      );

    message.channel.send({ embeds: [mentionEmbed], components: [buttons] }).catch(() => {});
  }
};
