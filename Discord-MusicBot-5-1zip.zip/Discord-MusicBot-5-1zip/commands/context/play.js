const { ContextMenuCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const escapeMarkdown = require("discord.js").Util.escapeMarkdown;

module.exports = {
  command: new ContextMenuCommandBuilder().setName("Phát bài hát này").setType(3),

  run: async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const node = await client.getLavalink(client);
    if (!node) {
      return interaction.reply({
        embeds: [client.ErrorEmbed("Máy chủ âm nhạc chưa kết nối!")],
      });
    }

    const player = client.createPlayer(interaction.channel, channel);
    if (player.state !== "CONNECTED") player.connect();

    if (channel.type === "GUILD_STAGE_VOICE") {
      setTimeout(() => {
        if (interaction.guild.members.me.voice.suppress) {
          try {
            interaction.guild.members.me.voice.setSuppressed(false);
          } catch {
            interaction.guild.members.me.voice.setRequestToSpeak(true);
          }
        }
      }, 2000);
    }

    const ret = await interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(":mag_right: **Đang tìm kiếm...**"),
      ],
      fetchReply: true,
    });

    const rawQuery =
      interaction.channel.messages.cache.get(interaction.targetId)?.content ??
      (await interaction.channel.messages.fetch(interaction.targetId)).content;

    if (!rawQuery) {
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không thể đọc nội dung tin nhắn.")],
      });
    }

    let res = await player.search(rawQuery, interaction.user).catch((err) => {
      client.error(err);
      return { loadType: "LOAD_FAILED" };
    });

    if (res.loadType === "LOAD_FAILED" || res.loadType === "NO_MATCHES") {
      if (!player.queue.current) player.destroy();
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription(
              res.loadType === "NO_MATCHES"
                ? "Không tìm thấy kết quả nào."
                : "Đã xảy ra lỗi khi tìm kiếm bài hát."
            ),
        ],
      }).catch(() => {});
    }

    if (res.loadType === "TRACK_LOADED" || res.loadType === "SEARCH_RESULT") {
      player.queue.add(res.tracks[0]);
      if (!player.playing && !player.paused && !player.queue.size) player.play();

      let title = escapeMarkdown(res.tracks[0].title).replace(/\]/g, "").replace(/\[/g, "");
      const addQueueEmbed = new MessageEmbed()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "Đã thêm vào hàng chờ", iconURL: client.config.iconURL })
        .setDescription(`[${title}](${res.tracks[0].uri})` || "Không có tiêu đề")
        .setURL(res.tracks[0].uri)
        .addFields(
          { name: "Thêm bởi", value: `<@${interaction.user.id}>`, inline: true },
          {
            name: "Thời lượng",
            value: res.tracks[0].isStream
              ? "`TRỰC TIẾP 🔴`"
              : `\`${client.ms(res.tracks[0].duration, { colonNotation: true, secondsDecimalDigits: 0 })}\``,
            inline: true,
          }
        );

      try {
        addQueueEmbed.setThumbnail(res.tracks[0].displayThumbnail("maxresdefault"));
      } catch {
        addQueueEmbed.setThumbnail(res.tracks[0].thumbnail);
      }

      if (player.queue.totalSize > 1) {
        addQueueEmbed.addFields({ name: "Vị trí hàng chờ", value: `${player.queue.size}`, inline: true });
      } else {
        player.queue.previous = player.queue.current;
      }

      await interaction.editReply({ embeds: [addQueueEmbed] }).catch(() => {});
    }

    if (res.loadType === "PLAYLIST_LOADED") {
      player.queue.add(res.tracks);
      if (!player.playing && !player.paused && player.queue.totalSize === res.tracks.length) player.play();

      const playlistEmbed = new MessageEmbed()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "Đã thêm playlist vào hàng chờ", iconURL: client.config.iconURL })
        .setThumbnail(res.tracks[0].thumbnail)
        .setDescription(`[${res.playlist.name}](${rawQuery})`)
        .addFields(
          { name: "Số bài", value: `\`${res.tracks.length}\` bài hát`, inline: true },
          {
            name: "Tổng thời lượng",
            value: `\`${client.ms(res.playlist.duration, { colonNotation: true, secondsDecimalDigits: 0 })}\``,
            inline: true,
          }
        );

      await interaction.editReply({ embeds: [playlistEmbed] }).catch(() => {});
    }

    if (ret) setTimeout(() => ret.delete().catch(() => {}), 20000);
    return ret;
  },
};
