const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("dung")
  .setDescription("Dừng phát nhạc và rời kênh thoại (xóa toàn bộ hàng chờ)")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Tôi không ở trong kênh thoại nào.")],
        ephemeral: true,
      });
    }

    if (player.twentyFourSeven) {
      player.queue.clear();
      player.stop();
      player.set("autoQueue", false);
    } else {
      player.destroy();
    }

    interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`:wave: | **Tạm biệt!**`),
      ],
    });
  });

module.exports = command;
