const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("ping")
  .setDescription("Xem độ trễ của bot")
  .setRun(async (client, interaction) => {
    const msg = await interaction.channel.send({
      embeds: [
        new MessageEmbed()
          .setDescription("🏓 | Đang đo ping...")
          .setColor("#6F8FAF"),
      ],
    }).catch(() => null);

    const zap = "⚡";
    const green = "🟢";
    const red = "🔴";
    const yellow = "🟡";

    let apiState = zap;
    let botState = zap;

    const apiPing = client.ws.ping;
    const botPing = msg ? Math.floor(msg.createdAt - interaction.createdAt) : -1;

    if (apiPing >= 40 && apiPing < 200) apiState = green;
    else if (apiPing >= 200 && apiPing < 400) apiState = yellow;
    else if (apiPing >= 400) apiState = red;

    if (botPing >= 40 && botPing < 200) botState = green;
    else if (botPing >= 200 && botPing < 400) botState = yellow;
    else if (botPing >= 400) botState = red;

    if (msg) msg.delete().catch(() => {});

    interaction.reply({
      embeds: [
        new MessageEmbed()
          .setTitle("🏓 | Pong!")
          .addFields(
            {
              name: "Độ trễ API",
              value: `\`\`\`yml\n${apiState} | ${apiPing}ms\`\`\``,
              inline: true,
            },
            {
              name: "Độ trễ Bot",
              value: `\`\`\`yml\n${botState} | ${botPing}ms\`\`\``,
              inline: true,
            }
          )
          .setColor(client.config.embedColor)
          .setFooter({
            text: `Yêu cầu bởi ${interaction.user.tag}`,
            iconURL: interaction.user.avatarURL(),
          }),
      ],
    });
  });

module.exports = command;
