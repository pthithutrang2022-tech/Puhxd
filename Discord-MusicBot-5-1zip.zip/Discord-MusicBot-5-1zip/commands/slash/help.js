const SlashCommand = require("../../lib/SlashCommand");
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");
const LoadCommands = require("../../util/loadCommands");

const command = new SlashCommand()
  .setName("tro-giup")
  .setDescription("Hiển thị danh sách tất cả lệnh của bot")
  .setRun(async (client, interaction) => {
    await interaction.deferReply().catch(() => {});

    const commands = await LoadCommands().then((cmds) => {
      return [].concat(cmds.slash);
    });

    const filteredCommands = commands.filter((cmd) => cmd.description !== "null");
    const totalCmds = filteredCommands.length;
    let maxPages = Math.ceil(totalCmds / client.config.helpCmdPerPage);

    let gitHash = "unknown";
    try {
      gitHash = require("child_process").execSync("git rev-parse --short HEAD").toString().trim();
    } catch {}

    let pageNo = 0;

    const helpEmbed = new MessageEmbed()
      .setColor(client.config.embedColor)
      .setAuthor({ name: `Lệnh của ${client.user.username}`, iconURL: client.config.iconURL })
      .setTimestamp()
      .setFooter({ text: `Trang ${pageNo + 1} / ${maxPages}` });

    let tempArray = filteredCommands.slice(
      pageNo * client.config.helpCmdPerPage,
      pageNo * client.config.helpCmdPerPage + client.config.helpCmdPerPage
    );

    tempArray.forEach((cmd) => {
      helpEmbed.addFields({ name: `/${cmd.name}`, value: cmd.description });
    });

    helpEmbed.addFields({
      name: "Thông tin",
      value:
        `Phiên bản: v${require("../../package.json").version} | Build: ${gitHash}` +
        "\n" +
        `[✨ Máy chủ hỗ trợ](${client.config.supportServer}) | [Mời bot](https://discord.com/oauth2/authorize?client_id=${client.config.clientId}&permissions=${client.config.permissions}&scope=bot%20applications.commands)`,
    });

    const getButtons = (pageNo) =>
      new MessageActionRow().addComponents(
        new MessageButton()
          .setCustomId("help_cmd_but_2_app")
          .setEmoji("◀️")
          .setStyle("PRIMARY")
          .setDisabled(pageNo === 0),
        new MessageButton()
          .setCustomId("help_cmd_but_1_app")
          .setEmoji("▶️")
          .setStyle("PRIMARY")
          .setDisabled(pageNo === maxPages - 1)
      );

    const tempMsg = await interaction.editReply({
      embeds: [helpEmbed],
      components: [getButtons(pageNo)],
      fetchReply: true,
    });

    const collector = tempMsg.createMessageComponentCollector({
      time: 600000,
      componentType: "BUTTON",
    });

    collector.on("collect", async (iter) => {
      if (iter.customId === "help_cmd_but_1_app") pageNo++;
      else if (iter.customId === "help_cmd_but_2_app") pageNo--;

      helpEmbed.fields = [];
      let arr = filteredCommands.slice(
        pageNo * client.config.helpCmdPerPage,
        pageNo * client.config.helpCmdPerPage + client.config.helpCmdPerPage
      );
      arr.forEach((cmd) => {
        helpEmbed
          .addFields({ name: `/${cmd.name}`, value: cmd.description })
          .setFooter({ text: `Trang ${pageNo + 1} / ${maxPages}` });
      });
      helpEmbed.addFields({
        name: "Thông tin",
        value:
          `Phiên bản: v${require("../../package.json").version} | Build: ${gitHash}` +
          "\n" +
          `[✨ Máy chủ hỗ trợ](${client.config.supportServer}) | [Mời bot](https://discord.com/oauth2/authorize?client_id=${client.config.clientId}&permissions=${client.config.permissions}&scope=bot%20applications.commands)`,
      });
      await iter.update({ embeds: [helpEmbed], components: [getButtons(pageNo)], fetchReply: true });
    });
  });

module.exports = command;
