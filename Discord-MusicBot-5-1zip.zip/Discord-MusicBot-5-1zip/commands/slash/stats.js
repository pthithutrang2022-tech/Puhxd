const SlashCommand = require("../../lib/SlashCommand");
const moment = require("moment");
require("moment-duration-format");
const { MessageEmbed } = require("discord.js");
const os = require("os");

const command = new SlashCommand()
  .setName("thong-ke")
  .setDescription("Xem thông tin và thống kê của bot")
  .setRun(async (client, interaction) => {
    const osver = os.platform() + " " + os.release();
    const nodeVersion = process.version;
    const runtime = moment
      .duration(client.uptime)
      .format("d[n]・h[g]・m[p]・s[s]");

    let lavauptime = "N/A";
    let lavaram = "N/A";
    let lavamem = "N/A";
    let lavaPlaying = "N/A";
    let lavaTotalPlayers = "N/A";

    try {
      const node = client.manager.nodes.values().next().value;
      if (node && node.stats) {
        lavauptime = moment.duration(node.stats.uptime).format("D[n] H[g] m[p]");
        lavaram = (node.stats.memory.used / 1024 / 1024).toFixed(2);
        lavamem = (node.stats.memory.allocated / 1024 / 1024).toFixed(2);
        lavaPlaying = node.stats.playingPlayers;
        lavaTotalPlayers = node.stats.players;
      }
    } catch {}

    const sysuptime = moment
      .duration(os.uptime() * 1000)
      .format("d[n]・h[g]・m[p]・s[s]");

    let gitHash = "unknown";
    try {
      gitHash = require("child_process").execSync("git rev-parse HEAD").toString().trim();
    } catch {}

    const statsEmbed = new MessageEmbed()
      .setTitle(`Thông tin ${client.user.username}`)
      .setColor(client.config.embedColor)
      .setDescription(
        `\`\`\`yml\nTên: ${client.user.username}#${client.user.discriminator} [${client.user.id}]\nAPI: ${client.ws.ping}ms\nThời gian chạy: ${runtime}\`\`\``
      )
      .setFields([
        {
          name: "Thống kê Lavalink",
          value: `\`\`\`yml\nThời gian chạy: ${lavauptime}\nRAM: ${lavaram} MB\nĐang phát: ${lavaPlaying}/${lavaTotalPlayers}\`\`\``,
          inline: true,
        },
        {
          name: "Thống kê bot",
          value: `\`\`\`yml\nMáy chủ: ${client.guilds.cache.size}\nNodeJS: ${nodeVersion}\nPhiên bản: v${require("../../package.json").version}\`\`\``,
          inline: true,
        },
        {
          name: "Thống kê hệ thống",
          value: `\`\`\`yml\nHệ điều hành: ${osver}\nThời gian hoạt động: ${sysuptime}\n\`\`\``,
          inline: false,
        },
      ])
      .setFooter({ text: `Build: ${gitHash}` });

    return interaction.reply({ embeds: [statsEmbed] });
  });

module.exports = command;
