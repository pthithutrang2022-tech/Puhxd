const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("lap-hang-cho")
  .setDescription("Bật/tắt lặp lại toàn bộ hàng chờ")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    player.setQueueRepeat(!player.queueRepeat);
    const trang_thai = player.queueRepeat ? "bật" : "tắt";

    interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`:thumbsup: | **Lặp hàng chờ đã được \`${trang_thai}\`**`),
      ],
    });
  });

module.exports = command;
