const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("lap-lai")
  .setDescription("Bật/tắt lặp lại bài hát hiện tại")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    player.setTrackRepeat(!player.trackRepeat);
    const trang_thai = player.trackRepeat ? "bật" : "tắt";

    interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`👍 | **Lặp lại bài hát đã được \`${trang_thai}\`**`),
      ],
    });
  });

module.exports = command;
