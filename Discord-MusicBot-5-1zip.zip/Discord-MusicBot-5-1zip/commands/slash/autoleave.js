const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("tu-roi")
  .setDescription("Tự động rời kênh thoại khi không còn ai (bật/tắt)")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát trong hàng chờ.")],
        ephemeral: true,
      });
    }

    const autoLeave = player.get("autoLeave");
    player.set("autoLeave", !autoLeave);

    const trang_thai = !autoLeave ? "BẬT" : "TẮT";
    const mo_ta = !autoLeave
      ? "Bot sẽ tự động rời kênh thoại khi không còn ai."
      : "Bot sẽ không tự động rời kênh thoại.";

    client.warn(
      `Player: ${player.options.guild} | [${colors.blue("TỰ RỜI")}] đã [${colors.blue(trang_thai)}]`
    );

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`**Tự động rời:** \`${trang_thai}\``)
          .setFooter({ text: mo_ta }),
      ],
    });
  });

module.exports = command;
