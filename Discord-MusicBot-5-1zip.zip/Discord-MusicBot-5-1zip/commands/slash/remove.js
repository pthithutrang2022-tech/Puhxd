const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("xoa-bai")
  .setDescription("Xóa một bài hát khỏi hàng chờ")
  .addNumberOption((option) =>
    option.setName("so-thu-tu").setDescription("Số thứ tự bài hát cần xóa.").setRequired(true)
  )
  .setRun(async (client, interaction) => {
    const args = interaction.options.getNumber("so-thu-tu");
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có bài hát nào để xóa.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const position = Number(args) - 1;
    if (position >= player.queue.size) {
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(`Hàng chờ hiện chỉ có **${player.queue.size}** bài hát`),
        ],
      });
    }

    player.queue.remove(position);
    const number = position + 1;

    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`Đã xóa bài hát số **${number}** khỏi hàng chờ`),
      ],
    });
  });

module.exports = command;
