const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("tu-tam-dung")
  .setDescription("Tự động tạm dừng khi không còn ai trong kênh thoại (bật/tắt)")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát trong hàng chờ.")],
        ephemeral: true,
      });
    }

    const autoPause = player.get("autoPause");
    player.set("autoPause", !autoPause);
    player.set("requester", interaction.guild.members.me);

    const trang_thai = !autoPause ? "BẬT" : "TẮT";
    const mo_ta = !autoPause
      ? "Bot sẽ tự động tạm dừng khi không còn ai trong kênh thoại."
      : "Bot sẽ không tự động tạm dừng nữa.";

    client.warn(
      `Player: ${player.options.guild} | [${colors.blue("TỰ TẠM DỪNG")}] đã [${colors.blue(trang_thai)}]`
    );

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`**Tự động tạm dừng:** \`${trang_thai}\``)
          .setFooter({ text: mo_ta }),
      ],
    });
  });

module.exports = command;
