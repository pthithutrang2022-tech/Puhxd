const SlashCommand = require("../../lib/SlashCommand");
const prettyMilliseconds = require("pretty-ms");
const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require("discord.js");

const command = new SlashCommand()
  .setName("tim-kiem")
  .setDescription("Tìm kiếm bài hát và chọn từ danh sách kết quả")
  .addStringOption((option) =>
    option
      .setName("query")
      .setDescription("Tên bài hát hoặc nghệ sĩ muốn tìm")
      .setRequired(true)
  )
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager
      ? client.createPlayer(interaction.channel, channel)
      : null;

    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Lavalink chưa kết nối!")],
      });
    }

    await interaction.deferReply().catch(() => {});

    if (player.state !== "CONNECTED") player.connect();

    const search = interaction.options.getString("query");
    let res;

    try {
      res = await player.search(`ytmsearch:${search}`, interaction.user);
      if (res.loadType === "LOAD_FAILED") {
        if (!player.queue.current) player.destroy();
        return interaction.editReply({
          embeds: [new MessageEmbed().setDescription("Đã xảy ra lỗi khi tìm kiếm bài hát.").setColor("RED")],
        });
      }
    } catch {
      if (!player.queue.current) player.destroy();
      return interaction.editReply({
        embeds: [new MessageEmbed().setDescription("Đã xảy ra lỗi khi tìm kiếm bài hát.").setColor("RED")],
      });
    }

    if (res.loadType === "NO_MATCHES") {
      if (!player.queue.current) player.destroy();
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setDescription(`Không tìm thấy kết quả nào cho \`${search}\``)
            .setColor("RED"),
        ],
      });
    }

    const max = Math.min(res.tracks.length, 10);
    const resultFromSearch = res.tracks.slice(0, max).map((track) => ({
      label: track.title.slice(0, 100),
      value: track.uri,
      description: track.isStream
        ? "TRỰC TIẾP"
        : `${prettyMilliseconds(track.duration, { secondsDecimalDigits: 0 })} - ${track.author}`.slice(0, 100),
    }));

    const menus = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId("select")
        .setPlaceholder("Chọn một bài hát")
        .addOptions(resultFromSearch)
    );

    const choosenTracks = await interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(
            `Đây là kết quả tìm kiếm cho \`${search}\`. Hãy chọn bài trong vòng \`30 giây\``
          ),
      ],
      components: [menus],
    });

    const filter = (button) => button.user.id === interaction.user.id;
    const tracksCollector = choosenTracks.createMessageComponentCollector({ filter, time: 30000 });

    tracksCollector.on("collect", async (i) => {
      if (i.isSelectMenu()) {
        await i.deferUpdate();
        const uriFromCollector = i.values[0];
        const trackForPlay = await player.search(uriFromCollector, interaction.user).catch(() => null);
        if (!trackForPlay || !trackForPlay.tracks[0]) return;

        player.queue.add(trackForPlay.tracks[0]);
        if (!player.playing && !player.paused && !player.queue.size) player.play();

        i.editReply({
          content: null,
          embeds: [
            new MessageEmbed()
              .setAuthor({ name: "Đã thêm vào hàng chờ", iconURL: client.config.iconURL })
              .setDescription(
                `[${trackForPlay.tracks[0].title}](${trackForPlay.tracks[0].uri})` || "Không có tiêu đề"
              )
              .addFields(
                { name: "Thêm bởi", value: `<@${interaction.user.id}>`, inline: true },
                {
                  name: "Thời lượng",
                  value: trackForPlay.tracks[0].isStream
                    ? "`TRỰC TIẾP 🔴`"
                    : `\`${client.ms(trackForPlay.tracks[0].duration, { colonNotation: true, secondsDecimalDigits: 0 })}\``,
                  inline: true,
                }
              )
              .setColor(client.config.embedColor),
          ],
          components: [],
        });
      }
    });

    tracksCollector.on("end", async (i) => {
      if (i.size === 0) {
        choosenTracks.edit({
          content: null,
          embeds: [
            new MessageEmbed()
              .setDescription("Không có bài nào được chọn. Bạn đã hết thời gian.")
              .setColor(client.config.embedColor),
          ],
          components: [],
        }).catch(() => {});
      }
    });
  });

module.exports = command;
