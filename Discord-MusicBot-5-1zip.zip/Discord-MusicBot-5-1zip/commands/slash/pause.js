const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("tam-dung")
  .setDescription("Tạm dừng bài hát đang phát")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    if (player.paused) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Bài hát đang phát đã được tạm dừng rồi!")],
        ephemeral: true,
      });
    }

    player.pause(true);
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("⏸ | **Đã tạm dừng!**"),
      ],
    });
  });

module.exports = command;
