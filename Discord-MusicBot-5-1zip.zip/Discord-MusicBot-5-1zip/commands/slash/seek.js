const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

// Parse time strings like "1h 30m", "2h", "80m", "53s", "1:30", "1:30:00"
function parseTime(timeStr) {
  let total = 0;
  const parts = timeStr.trim().split(/\s+/);
  for (const part of parts) {
    const hours = part.match(/^(\d+)h$/i);
    const mins = part.match(/^(\d+)m$/i);
    const secs = part.match(/^(\d+)s$/i);
    const hms = part.match(/^(\d+):(\d+):(\d+)$/);
    const ms2 = part.match(/^(\d+):(\d+)$/);
    if (hours) total += parseInt(hours[1]) * 3600000;
    else if (mins) total += parseInt(mins[1]) * 60000;
    else if (secs) total += parseInt(secs[1]) * 1000;
    else if (hms) total += (parseInt(hms[1]) * 3600 + parseInt(hms[2]) * 60 + parseInt(hms[3])) * 1000;
    else if (ms2) total += (parseInt(ms2[1]) * 60 + parseInt(ms2[2])) * 1000;
  }
  return total;
}

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}

const command = new SlashCommand()
  .setName("tua")
  .setDescription("Tua đến một thời điểm trong bài hát.")
  .addStringOption((option) =>
    option
      .setName("thoi-gian")
      .setDescription("Thời gian muốn tua tới. VD: 1h 30m | 2h | 80m | 53s | 1:30")
      .setRequired(true)
  )
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const rawArgs = interaction.options.getString("thoi-gian");
    const time = parseTime(rawArgs);
    const duration = player.queue.current.duration;
    const position = player.position;

    if (!time || time <= 0) {
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Định dạng thời gian không hợp lệ. VD: `1h 30m`, `2h`, `80m`, `53s`, `1:30`"),
        ],
      });
    }

    if (time <= duration) {
      player.seek(time);
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(
              `⏩ | **${player.queue.current.title}** đã được ${
                time < position ? "tua lại" : "tua tới"
              } **${formatTime(time)}**`
            ),
        ],
      });
    } else {
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription(
              "Không thể tua đến thời điểm này. Thời gian vượt quá độ dài bài hát hoặc định dạng không hợp lệ."
            ),
        ],
      });
    }
  });

module.exports = command;
