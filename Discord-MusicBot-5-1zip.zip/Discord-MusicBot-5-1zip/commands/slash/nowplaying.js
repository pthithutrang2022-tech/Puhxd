const { MessageEmbed } = require("discord.js");
const escapeMarkdown = require("discord.js").Util.escapeMarkdown;
const SlashCommand = require("../../lib/SlashCommand");
const prettyMilliseconds = require("pretty-ms");

const command = new SlashCommand()
  .setName("dang-phat")
  .setDescription("Xem thông tin bài hát đang phát trong kênh thoại.")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Bot không ở trong kênh thoại nào.")],
        ephemeral: true,
      });
    }

    if (!player.playing) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    const song = player.queue.current;
    let title = escapeMarkdown(song.title).replace(/\]/g, "").replace(/\[/g, "");
    const embed = new MessageEmbed()
      .setColor(client.config.embedColor)
      .setAuthor({ name: "Đang phát", iconURL: client.config.iconURL })
      .setFields([
        {
          name: "Yêu cầu bởi",
          value: `<@${song.requester.id}>`,
          inline: true,
        },
        {
          name: "Thời lượng",
          value: song.isStream
            ? "`TRỰC TIẾP 🔴`"
            : `\`${prettyMilliseconds(player.position, { secondsDecimalDigits: 0 })} / ${prettyMilliseconds(song.duration, { secondsDecimalDigits: 0 })}\``,
          inline: true,
        },
      ])
      .setDescription(`[${title}](${song.uri})`);

    try {
      embed.setThumbnail(song.displayThumbnail("maxresdefault"));
    } catch {
      embed.setThumbnail(song.thumbnail);
    }

    return interaction.reply({ embeds: [embed] });
  });

module.exports = command;
