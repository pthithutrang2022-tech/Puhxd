const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("phat-lai")
  .setDescription("Phát lại bài hát từ đầu")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    player.seek(0);
    const song = player.queue.current;

    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`🔄 | Đang phát lại [${song.title}](${song.uri})`),
      ],
    });
  });

module.exports = command;
