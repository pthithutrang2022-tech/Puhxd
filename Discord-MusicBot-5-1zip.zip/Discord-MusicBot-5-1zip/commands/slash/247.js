const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("che-do-247")
  .setDescription("Bot ở lại kênh thoại 24/7, không tự ngắt kết nối (bật/tắt)")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    const twentyFourSeven = player.get("twentyFourSeven");

    if (!twentyFourSeven || twentyFourSeven === false) {
      player.set("twentyFourSeven", true);
    } else {
      player.set("twentyFourSeven", false);
    }

    const trang_thai = !twentyFourSeven ? "BẬT" : "TẮT";
    const mo_ta = !twentyFourSeven
      ? "Bot sẽ ở lại kênh thoại 24/7."
      : "Bot sẽ không còn ở lại 24/7 nữa.";

    client.warn(
      `Player: ${player.options.guild} | [${colors.blue("24/7")}] đã [${colors.blue(!twentyFourSeven ? "BẬT" : "TẮT")}]`
    );

    if (!player.playing && player.queue.totalSize === 0 && twentyFourSeven) {
      player.destroy();
    }

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`**Chế độ 24/7:** \`${trang_thai}\``)
          .setFooter({ text: mo_ta }),
      ],
    });
  });

module.exports = command;
