const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");
const fs = require("fs");
const path = require("path");

const command = new SlashCommand()
  .setName("tai-lai")
  .setDescription("Tải lại tất cả lệnh (chỉ admin)")
  .setRun(async (client, interaction) => {
    if (interaction.user.id !== client.config.adminId) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Bạn không có quyền dùng lệnh này!"),
        ],
        ephemeral: true,
      });
    }

    try {
      const contextDir = path.join(__dirname, "..", "context");
      fs.readdir(contextDir, (err, files) => {
        if (err || !files) return;
        files.forEach((file) => {
          delete require.cache[require.resolve(contextDir + "/" + file)];
          const cmd = require(contextDir + "/" + file);
          if (!cmd || !cmd.run) return;
          client.contextCommands.set(file.split(".")[0].toLowerCase(), cmd);
        });
      });

      const slashDir = path.join(__dirname, "..", "slash");
      fs.readdir(slashDir, (err, files) => {
        if (err || !files) return;
        files.forEach((file) => {
          delete require.cache[require.resolve(slashDir + "/" + file)];
          const cmd = require(slashDir + "/" + file);
          if (!cmd || !cmd.run) return;
          client.slashCommands.set(file.split(".")[0].toLowerCase(), cmd);
        });
      });

      const totalCmds = client.slashCommands.size + client.contextCommands.size;
      client.log(`Đã tải lại ${totalCmds} lệnh!`);

      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(`✅ Đã tải lại thành công \`${totalCmds}\` lệnh!`)
            .setFooter({ text: `${client.user.username} đã được tải lại bởi ${interaction.user.username}` })
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    } catch (err) {
      client.error(err);
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Đã xảy ra lỗi. Vui lòng kiểm tra console."),
        ],
        ephemeral: true,
      });
    }
  });

module.exports = command;
