const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("di-chuyen")
  .setDescription("Di chuyển bài hát đến vị trí khác trong hàng chờ")
  .addIntegerOption((option) =>
    option.setName("bai-hat").setDescription("Số thứ tự bài hát muốn di chuyển").setRequired(true)
  )
  .addIntegerOption((option) =>
    option.setName("vi-tri").setDescription("Vị trí mới muốn di chuyển đến").setRequired(true)
  )
  .setRun(async (client, interaction) => {
    const track = interaction.options.getInteger("bai-hat");
    const position = interaction.options.getInteger("vi-tri");
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    const trackNum = Number(track) - 1;
    if (trackNum < 0 || trackNum > player.queue.length - 1) {
      return interaction.reply(":x: | **Số thứ tự bài hát không hợp lệ**");
    }

    const dest = Number(position) - 1;
    if (dest < 0 || dest > player.queue.length - 1) {
      return interaction.reply(":x: | **Vị trí đích không hợp lệ**");
    }

    const thing = player.queue[trackNum];
    player.queue.splice(trackNum, 1);
    player.queue.splice(dest, 0, thing);

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(":white_check_mark: | **Đã di chuyển bài hát**"),
      ],
    });
  });

module.exports = command;
