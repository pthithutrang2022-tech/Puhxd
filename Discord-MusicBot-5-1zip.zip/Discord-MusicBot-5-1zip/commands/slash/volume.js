const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("am-luong")
  .setDescription("Thay đổi âm lượng hiện tại.")
  .addNumberOption((option) =>
    option
      .setName("so-luong")
      .setDescription("Mức âm lượng muốn đặt (1-125). Ví dụ: 80")
      .setRequired(false)
  )
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    const vol = interaction.options.getNumber("so-luong");
    if (!vol || vol < 1 || vol > 125) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(`:loud_sound: | Âm lượng hiện tại: **${player.volume}**`),
        ],
      });
    }

    player.setVolume(vol);
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`:loud_sound: | Đã đặt âm lượng thành **${player.volume}**`),
      ],
    });
  });

module.exports = command;
