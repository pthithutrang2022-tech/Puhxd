const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("truoc-do")
  .setDescription("Quay lại bài hát trước đó.")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có bài hát nào trước đó trong phiên này.")],
        ephemeral: true,
      });
    }

    const previousSong = player.queue.previous;
    const currentSong = player.queue.current;
    const nextSong = player.queue[0];

    if (!previousSong || previousSong === currentSong || previousSong === nextSong) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Không có bài hát nào trước đó trong hàng chờ."),
        ],
      });
    }

    if (previousSong !== currentSong && previousSong !== nextSong) {
      player.queue.splice(0, 0, currentSong);
      player.play(previousSong);
    }

    interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`⏮ | Bài trước: **${previousSong.title}**`),
      ],
    });
  });

module.exports = command;
