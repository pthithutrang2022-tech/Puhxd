const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("don-dep")
  .setDescription("Xóa các tin nhắn của bot trong kênh (tối đa 100 tin).")
  .addIntegerOption((option) =>
    option
      .setName("so-luong")
      .setDescription("Số tin nhắn muốn xóa.")
      .setMinValue(2)
      .setMaxValue(100)
      .setRequired(false)
  )
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    let number = interaction.options.getInteger("so-luong");
    number = number && number < 100 ? ++number : 100;

    interaction.channel.messages
      .fetch({ limit: number })
      .then((messages) => {
        const botMessages = [];
        messages
          .filter((m) => m.author.id === client.user.id)
          .forEach((msg) => botMessages.push(msg));

        botMessages.shift();
        interaction.channel
          .bulkDelete(botMessages, true)
          .then(async (deletedMessages) => {
            await interaction.editReply({
              embeds: [
                client.Embed(
                  `:white_check_mark: | Đã xóa ${botMessages.length} tin nhắn của bot`
                ),
              ],
            });
            setTimeout(() => interaction.deleteReply().catch(() => {}), 5000);
          })
          .catch(() => {});
      })
      .catch(() => {});
  });

module.exports = command;
