const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("roi-may-chu")
  .setDescription("Rời khỏi một máy chủ Discord (chỉ admin)")
  .addStringOption((option) =>
    option
      .setName("id")
      .setDescription("Nhập ID máy chủ cần rời (gõ `list` để xem danh sách)")
      .setRequired(true)
  )
  .setRun(async (client, interaction) => {
    if (interaction.user.id !== client.config.adminId) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Bạn không có quyền dùng lệnh này!"),
        ],
        ephemeral: true,
      });
    }

    try {
      const id = interaction.options.getString("id");

      if (id.toLowerCase() === "list") {
        const guilds = client.guilds.cache.map((g) => `${g.name} | ${g.id}`);
        try {
          return interaction.reply({
            content: `Danh sách máy chủ:\n\`${guilds.join("\n")}\``,
            ephemeral: true,
          });
        } catch {
          return interaction.reply({ content: "Kiểm tra console để xem danh sách máy chủ.", ephemeral: true });
        }
      }

      const guild = client.guilds.cache.get(id);
      if (!guild) {
        return interaction.reply({ content: `\`${id}\` không phải ID máy chủ hợp lệ`, ephemeral: true });
      }

      await guild.leave();
      return interaction.reply({ content: `Đã rời máy chủ \`${id}\``, ephemeral: true });
    } catch (error) {
      client.error(error);
      return interaction.reply({ content: "Đã xảy ra lỗi khi rời máy chủ.", ephemeral: true });
    }
  });

module.exports = command;
