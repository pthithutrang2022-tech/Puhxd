const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("tu-hang-cho")
  .setDescription("Tự động thêm bài hát liên quan khi hàng chờ trống (bật/tắt)")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát trong hàng chờ.")],
        ephemeral: true,
      });
    }

    const autoQueue = player.get("autoQueue");
    player.set("requester", interaction.guild.members.me);

    if (!autoQueue || autoQueue === false) {
      player.set("autoQueue", true);
    } else {
      player.set("autoQueue", false);
    }

    const trang_thai = !autoQueue ? "BẬT" : "TẮT";
    const mo_ta = !autoQueue
      ? "Bài hát liên quan sẽ tự động được thêm vào hàng chờ."
      : "Bài hát liên quan sẽ không còn tự động được thêm nữa.";

    client.warn(
      `Player: ${player.options.guild} | [${colors.blue("TỰ HÀNG CHỜ")}] đã [${colors.blue(!autoQueue ? "BẬT" : "TẮT")}]`
    );

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`**Tự động thêm nhạc:** \`${trang_thai}\``)
          .setFooter({ text: mo_ta }),
      ],
    });
  });

module.exports = command;
