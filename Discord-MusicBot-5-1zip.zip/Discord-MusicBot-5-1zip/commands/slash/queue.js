const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const escapeMarkdown = require("discord.js").Util.escapeMarkdown;
const load = require("lodash");
const pms = require("pretty-ms");

const command = new SlashCommand()
  .setName("hang-cho")
  .setDescription("Xem hàng chờ phát nhạc hiện tại")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có bài hát nào trong hàng chờ.")],
        ephemeral: true,
      });
    }

    if (!player.playing) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply().catch(() => {});

    const sanitize = (title) => escapeMarkdown(title).replace(/\]/g, "").replace(/\[/g, "");

    if (!player.queue.size || player.queue.size === 0) {
      const song = player.queue.current;
      const title = sanitize(song.title);
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(`**♪ | Đang phát:** [${title}](${song.uri})`)
            .addFields(
              {
                name: "Thời lượng",
                value: song.isStream
                  ? "`TRỰC TIẾP`"
                  : `\`${pms(player.position, { colonNotation: true })} / ${pms(player.queue.current.duration, { colonNotation: true })}\``,
                inline: true,
              },
              { name: "Âm lượng", value: `\`${player.volume}\``, inline: true },
              { name: "Tổng bài", value: `\`${player.queue.totalSize - 1}\``, inline: true }
            ),
        ],
      });
    }

    let queueDuration = player.queue.duration.valueOf();
    if (player.queue.current.isStream) queueDuration -= player.queue.current.duration;
    for (const t of player.queue) {
      if (t.isStream) queueDuration -= t.duration;
    }

    const mapping = player.queue.map((t, i) => `\` ${++i} \` [${t.title}](${t.uri}) [<@${t.requester?.id || "?"}>]`);
    const chunk = load.chunk(mapping, 10);
    const pages = chunk.map((s) => s.join("\n"));

    let page = 0;

    const buildEmbed = (song, pg) => {
      const title = sanitize(song.title);
      return new MessageEmbed()
        .setColor(client.config.embedColor)
        .setDescription(
          `**♪ | Đang phát:** [${title}](${song.uri}) [<@${song.requester?.id || "?"}>]\n\n**Hàng chờ**\n${pages[pg]}`
        )
        .addFields(
          {
            name: "Thời lượng bài",
            value: song.isStream
              ? "`TRỰC TIẾP`"
              : `\`${pms(player.position, { colonNotation: true })} / ${pms(player.queue.current.duration, { colonNotation: true })}\``,
            inline: true,
          },
          {
            name: "Tổng thời lượng",
            value: `\`${pms(queueDuration, { colonNotation: true })}\``,
            inline: true,
          },
          { name: "Tổng bài", value: `\`${player.queue.totalSize - 1}\``, inline: true }
        )
        .setFooter({ text: `Trang ${pg + 1}/${pages.length}` });
    };

    if (player.queue.size < 11) {
      return interaction.editReply({ embeds: [buildEmbed(player.queue.current, page)] });
    }

    const buttonNext = new MessageButton().setCustomId("queue_cmd_but_1_app").setEmoji("⏭️").setStyle("PRIMARY");
    const buttonPrev = new MessageButton().setCustomId("queue_cmd_but_2_app").setEmoji("⏮️").setStyle("PRIMARY");

    await interaction.editReply({
      embeds: [buildEmbed(player.queue.current, page)],
      components: [new MessageActionRow().addComponents([buttonPrev, buttonNext])],
    }).catch(() => {});

    const collector = interaction.channel.createMessageComponentCollector({
      filter: (b) => {
        if (b.user.id === interaction.user.id) return true;
        b.reply({ content: `Chỉ **${interaction.user.tag}** mới có thể dùng nút này.`, ephemeral: true }).catch(() => {});
        return false;
      },
      time: 300000,
      idle: 30000,
    });

    collector.on("collect", async (button) => {
      await button.deferUpdate().catch(() => {});
      if (button.customId === "queue_cmd_but_1_app") {
        page = page + 1 < pages.length ? ++page : 0;
      } else if (button.customId === "queue_cmd_but_2_app") {
        page = page > 0 ? --page : pages.length - 1;
      }
      await interaction.editReply({
        embeds: [buildEmbed(player.queue.current, page)],
        components: [new MessageActionRow().addComponents([buttonPrev, buttonNext])],
      }).catch(() => {});
    });
  });

module.exports = command;
