const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("bo-qua-den")
  .setDescription("Bỏ qua đến vị trí cụ thể trong hàng chờ")
  .addNumberOption((option) =>
    option
      .setName("vi-tri")
      .setDescription("Số thứ tự của bài hát muốn bỏ qua đến")
      .setRequired(true)
  )
  .setRun(async (client, interaction) => {
    const args = interaction.options.getNumber("vi-tri");
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Tôi không ở trong kênh thoại nào.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const position = Number(args);

    try {
      if (!position || position < 0 || position > player.queue.size) {
        return interaction.editReply({
          embeds: [
            new MessageEmbed()
              .setColor("RED")
              .setDescription("❌ | Vị trí không hợp lệ!"),
          ],
        });
      }

      player.queue.remove(0, position - 1);
      player.stop();

      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription("✅ | Đã bỏ qua đến vị trí " + position),
        ],
      });
    } catch {
      if (position === 1) player.stop();
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription("✅ | Đã bỏ qua đến vị trí " + position),
        ],
      });
    }
  });

module.exports = command;
