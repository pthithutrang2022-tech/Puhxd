const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("xao-tron")
  .setDescription("Xáo trộn ngẫu nhiên hàng chờ")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    if (!player.queue || !player.queue.length || player.queue.length === 0) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không đủ bài hát trong hàng chờ để xáo trộn.")],
        ephemeral: true,
      });
    }

    player.queue.shuffle();
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("🔀 | **Đã xáo trộn hàng chờ thành công.**"),
      ],
    });
  });

module.exports = command;
