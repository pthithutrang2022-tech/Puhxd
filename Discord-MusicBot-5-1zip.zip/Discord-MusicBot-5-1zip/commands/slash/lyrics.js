const SlashCommand = require("../../lib/SlashCommand");
const { MessageActionRow, MessageSelectMenu, MessageButton, MessageEmbed } = require("discord.js");
const { Rlyrics } = require("rlyrics");
const lyricsApi = new Rlyrics();

const command = new SlashCommand()
  .setName("loi-bai-hat")
  .setDescription("Tìm kiếm lời bài hát")
  .addStringOption((option) =>
    option
      .setName("bai-hat")
      .setDescription("Tên bài hát (để trống để lấy lời bài đang phát)")
      .setRequired(false)
  )
  .setRun(async (client, interaction) => {
    await interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("🔎 | **Đang tìm kiếm...**"),
      ],
    });

    const player = client.manager?.players.get(interaction.guild.id);
    const args = interaction.options.getString("bai-hat");

    if (!args && !player) {
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát và bạn chưa nhập tên bài hát.")],
      });
    }

    const phrasesToRemove = [
      "Full Video", "Full Audio", "Official Music Video", "Lyrics", "Lyrical Video",
      "Feat\\.", "Ft\\.", "Official", "Audio", "Video", "HD", "4K", "Remix", "Lyric Video",
      "Extended", "DJ Edit", "with Lyrics", "Karaoke", "Instrumental", "Live", "Acoustic",
      "Cover", "\\(feat\\. .*?\\)", "\\[NCS Release\\]",
    ];

    let query = args;
    if (!args && player?.queue?.current) {
      let title = player.queue.current.title;
      title = title
        .replace(new RegExp(phrasesToRemove.join("|"), "gi"), "")
        .replace(/\s*([\[\(].*?[\]\)])?\s*(\|.*)?\s*(\*.*)?$/, "")
        .trim();
      query = title;
    }

    lyricsApi.search(query).then(async (lyricsData) => {
      if (!lyricsData || lyricsData.length === 0) {
        const tipsBtn = new MessageActionRow().addComponents(
          new MessageButton().setEmoji("📌").setCustomId("tipsbutton").setLabel("Mẹo").setStyle("SECONDARY")
        );
        return interaction.editReply({
          embeds: [
            new MessageEmbed()
              .setColor("RED")
              .setDescription(`Không tìm thấy kết quả nào cho \`${query}\`!\nHãy kiểm tra lại tên bài hát.`),
          ],
          components: [tipsBtn],
        });
      }

      const lyricsResults = [];
      for (let i = 0; i < Math.min(lyricsData.length, client.config.lyricsMaxResults); i++) {
        if (lyricsData[i]) {
          lyricsResults.push({
            label: lyricsData[i].title.slice(0, 100),
            description: lyricsData[i].artist.slice(0, 100),
            value: i.toString(),
          });
        }
      }

      const menu = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId("choose-lyrics")
          .setPlaceholder("Chọn một bài hát")
          .addOptions(lyricsResults)
      );

      const selectedLyrics = await interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription(
              `Tìm thấy kết quả cho \`${query}\`. Vui lòng chọn trong vòng \`30 giây\`.`
            ),
        ],
        components: [menu],
      });

      const filter = (button) => button.user.id === interaction.user.id;
      const collector = selectedLyrics.createMessageComponentCollector({ filter, time: 30000 });

      collector.on("collect", async (i) => {
        if (i.isSelectMenu()) {
          await i.deferUpdate();
          const url = lyricsData[parseInt(i.values[0])].url;

          lyricsApi.find(url).then((lyrics) => {
            let lyricsText = lyrics.lyrics;
            const musixmatch_icon = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Musixmatch_logo_icon_only.svg/480px-Musixmatch_logo_icon_only.svg.png";

            const button = new MessageActionRow().addComponents(
              new MessageButton().setCustomId("tipsbutton").setLabel("Mẹo").setEmoji("📌").setStyle("SECONDARY"),
              new MessageButton().setLabel("Nguồn").setURL(url).setStyle("LINK")
            );

            const lyricsEmbed = new MessageEmbed()
              .setColor(client.config.embedColor)
              .setTitle(lyrics.name)
              .setURL(url)
              .setThumbnail(lyrics.icon)
              .setFooter({ text: "Lời bài hát từ MusixMatch.", iconURL: musixmatch_icon });

            if (!lyricsText || lyricsText.length === 0) {
              lyricsEmbed
                .setDescription("**Chúng tôi không được phép hiển thị lời bài hát này.**")
                .setFooter({ text: "Lời bài hát bị MusixMatch giới hạn.", iconURL: musixmatch_icon });
            } else {
              if (lyricsText.length > 4096) lyricsText = lyricsText.substring(0, 4050) + "\n\n[...]";
              lyricsEmbed.setDescription(lyricsText);
            }

            return i.editReply({ embeds: [lyricsEmbed], components: [button] });
          }).catch(() => {});
        }
      });

      collector.on("end", async (i) => {
        if (i.size === 0) {
          selectedLyrics.edit({
            content: null,
            embeds: [new MessageEmbed().setDescription("Không có bài hát nào được chọn. Hết thời gian.").setColor(client.config.embedColor)],
            components: [],
          }).catch(() => {});
        }
      });
    }).catch((err) => {
      client.error(err);
      interaction.editReply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Đã xảy ra lỗi không xác định. Vui lòng thử lại.")],
      }).catch(() => {});
    });

    const tipsCollector = interaction.channel.createMessageComponentCollector({ time: 1000 * 3600 });
    tipsCollector.on("collect", async (i) => {
      if (i.customId === "tipsbutton") {
        await i.deferUpdate();
        await i.followUp({
          embeds: [
            new MessageEmbed()
              .setTitle("Mẹo tìm lời bài hát")
              .setColor(client.config.embedColor)
              .setDescription(
                "Dưới đây là một số mẹo để tìm lời bài hát chính xác:\n\n" +
                "1. Thêm tên nghệ sĩ vào trước tên bài hát.\n" +
                "2. Thử tìm kiếm thủ công bằng cách nhập tên bài hát.\n" +
                "3. Tránh tìm kiếm lời bài hát bằng tiếng Việt (chỉ hỗ trợ tốt tiếng Anh)."
              ),
          ],
          ephemeral: true,
          components: [],
        });
      }
    });
  });

module.exports = command;
