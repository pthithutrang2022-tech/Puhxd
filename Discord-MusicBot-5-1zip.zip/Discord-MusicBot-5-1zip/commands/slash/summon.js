const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("trieu-hoi")
  .setDescription("Triệu hồi bot vào kênh thoại của bạn.")
  .setRun(async (client, interaction) => {
    if (!interaction.member.voice.channel) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor(client.config.embedColor)
            .setDescription("❌ | **Bạn phải ở trong kênh thoại để dùng lệnh này.**"),
        ],
        ephemeral: true,
      });
    }

    const channel = interaction.member.voice.channel;
    let player = client.manager.players.get(interaction.guild.id);

    if (!player) {
      player = client.createPlayer(interaction.channel, channel);
      player.connect();
    } else if (channel.id !== player.voiceChannel) {
      player.setVoiceChannel(channel.id);
      player.connect();
    }

    interaction.reply({
      embeds: [
        client.Embed(`:thumbsup: | **Đã tham gia <#${channel.id}>!**`),
      ],
    });
  });

module.exports = command;
