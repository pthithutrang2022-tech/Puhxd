const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("xoa-hang-cho")
  .setDescription("Xóa toàn bộ hàng chờ")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có gì đang phát.")],
        ephemeral: true,
      });
    }

    if (!player.queue || !player.queue.length || player.queue.length === 0) {
      return interaction.reply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("❌ | **Hàng chờ trống, không có gì để xóa.**"),
        ],
        ephemeral: true,
      });
    }

    player.queue.clear();

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("✅ | **Đã xóa toàn bộ hàng chờ!**"),
      ],
    });
  });

module.exports = command;
