const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const prettyMilliseconds = require("pretty-ms");

const command = new SlashCommand()
  .setName("luu")
  .setDescription("Lưu bài hát đang phát vào tin nhắn riêng của bạn")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    const song = player.queue.current;
    const dmEmbed = new MessageEmbed()
      .setColor(client.config.embedColor)
      .setAuthor({
        name: "Bài hát đã lưu",
        iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
      })
      .setDescription(`**Đã lưu [${song.title}](${song.uri}) vào DM của bạn**`)
      .addFields(
        {
          name: "Thời lượng",
          value: `\`${prettyMilliseconds(song.duration, { colonNotation: true })}\``,
          inline: true,
        },
        {
          name: "Nghệ sĩ",
          value: `\`${song.author}\``,
          inline: true,
        },
        {
          name: "Máy chủ",
          value: `\`${interaction.guild.name}\``,
          inline: true,
        }
      );

    interaction.user.send({ embeds: [dmEmbed] }).catch(() => {});

    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(
            "Vui lòng kiểm tra **tin nhắn riêng** của bạn. Nếu không nhận được, hãy mở DM và thử lại."
          ),
      ],
      ephemeral: true,
    });
  });

module.exports = command;
