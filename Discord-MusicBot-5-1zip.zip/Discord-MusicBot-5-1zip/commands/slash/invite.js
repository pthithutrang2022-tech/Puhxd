const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("moi")
  .setDescription("Lấy link mời bot vào máy chủ của bạn")
  .setRun(async (client, interaction) => {
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setTitle("Mời bot vào máy chủ của bạn!")
          .setDescription("Nhấn nút bên dưới để mời bot."),
      ],
      components: [
        new MessageActionRow().addComponents(
          new MessageButton()
            .setLabel("Mời bot")
            .setStyle("LINK")
            .setURL(
              `https://discord.com/oauth2/authorize?client_id=${
                client.config.clientId
              }&permissions=${
                client.config.permissions
              }&scope=${client.config.inviteScopes
                .toString()
                .replace(/,/g, "%20")}`
            )
        ),
      ],
    });
  });

module.exports = command;
