const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const escapeMarkdown = require("discord.js").Util.escapeMarkdown;

// Detect if query is a direct URL
function isUrl(str) {
  return /^https?:\/\//i.test(str);
}

// Prepare search query: URLs pass through, text uses ytmsearch for better quality
function buildSearchQuery(query) {
  if (isUrl(query)) return query;
  return `ytmsearch:${query}`;
}

const command = new SlashCommand()
  .setName("phat")
  .setDescription(
    "Tìm kiếm và phát nhạc theo yêu cầu\nHỗ trợ: YouTube, YouTube Music, SoundCloud, Deezer, Apple Music, Bandcamp, Vimeo, Twitch, Radio/Stream, URL trực tiếp"
  )
  .addStringOption((option) =>
    option
      .setName("query")
      .setDescription("Tên bài hát, nghệ sĩ hoặc URL")
      .setAutocomplete(true)
      .setRequired(true)
  )
  .setRun(async (client, interaction, options) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const node = await client.getLavalink(client);
    if (!node) {
      return interaction.reply({
        embeds: [client.ErrorEmbed("Máy chủ âm nhạc chưa kết nối!")],
      });
    }

    const player = client.createPlayer(interaction.channel, channel);
    if (player.state !== "CONNECTED") player.connect();

    if (channel.type === "GUILD_STAGE_VOICE") {
      setTimeout(() => {
        if (interaction.guild.members.me.voice.suppress) {
          try {
            interaction.guild.members.me.voice.setSuppressed(false);
          } catch {
            interaction.guild.members.me.voice.setRequestToSpeak(true);
          }
        }
      }, 2000);
    }

    const ret = await interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(":mag_right: **Đang tìm kiếm...**"),
      ],
      fetchReply: true,
    });

    const rawQuery = options.getString("query", true);
    const searchQuery = buildSearchQuery(rawQuery);

    let res = await player.search(searchQuery, interaction.user).catch((err) => {
      client.error(err);
      return { loadType: "LOAD_FAILED" };
    });

    // Fallback: if ytmsearch fails, try ytsearch
    if (
      (res.loadType === "LOAD_FAILED" || res.loadType === "NO_MATCHES") &&
      !isUrl(rawQuery) &&
      searchQuery.startsWith("ytmsearch:")
    ) {
      res = await player.search(`ytsearch:${rawQuery}`, interaction.user).catch(() => ({
        loadType: "LOAD_FAILED",
      }));
    }

    // Fallback for Apple Music / Deezer URL failures: extract search terms and search YouTube Music
    if (
      (res.loadType === "LOAD_FAILED" || res.loadType === "NO_MATCHES") &&
      isUrl(rawQuery) &&
      /music\.apple\.com|deezer\.com/.test(rawQuery)
    ) {
      // Try extracting text from URL path as search query
      const pathParts = new URL(rawQuery).pathname
        .split("/")
        .filter((p) => p && p !== "album" && p !== "artist" && p !== "track" && p !== "playlist")
        .map((p) => p.replace(/-/g, " "))
        .join(" ")
        .trim();
      if (pathParts) {
        res = await player.search(`ytmsearch:${pathParts}`, interaction.user).catch(() => ({
          loadType: "LOAD_FAILED",
        }));
      }
    }

    if (res.loadType === "LOAD_FAILED") {
      if (!player.queue.current) player.destroy();
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Đã xảy ra lỗi khi tìm kiếm bài hát."),
        ],
      }).catch(() => {});
    }

    if (res.loadType === "NO_MATCHES") {
      if (!player.queue.current) player.destroy();
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription("Không tìm thấy kết quả nào."),
        ],
      }).catch(() => {});
    }

    if (res.loadType === "TRACK_LOADED" || res.loadType === "SEARCH_RESULT") {
      player.queue.add(res.tracks[0]);
      if (!player.playing && !player.paused && !player.queue.size) player.play();

      let title = escapeMarkdown(res.tracks[0].title).replace(/\]/g, "").replace(/\[/g, "");
      const addQueueEmbed = new MessageEmbed()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "Đã thêm vào hàng chờ", iconURL: client.config.iconURL })
        .setDescription(`[${title}](${res.tracks[0].uri})` || "Không có tiêu đề")
        .setURL(res.tracks[0].uri)
        .addFields(
          { name: "Thêm bởi", value: `<@${interaction.user.id}>`, inline: true },
          {
            name: "Thời lượng",
            value: res.tracks[0].isStream
              ? "`TRỰC TIẾP 🔴`"
              : `\`${client.ms(res.tracks[0].duration, {
                  colonNotation: true,
                  secondsDecimalDigits: 0,
                })}\``,
            inline: true,
          }
        );

      try {
        addQueueEmbed.setThumbnail(res.tracks[0].displayThumbnail("maxresdefault"));
      } catch {
        addQueueEmbed.setThumbnail(res.tracks[0].thumbnail);
      }

      if (player.queue.totalSize > 1) {
        addQueueEmbed.addFields({
          name: "Vị trí trong hàng chờ",
          value: `${player.queue.size}`,
          inline: true,
        });
      } else {
        player.queue.previous = player.queue.current;
      }

      await interaction.editReply({ embeds: [addQueueEmbed] }).catch(() => {});
    }

    if (res.loadType === "PLAYLIST_LOADED") {
      player.queue.add(res.tracks);
      if (!player.playing && !player.paused && player.queue.totalSize === res.tracks.length) {
        player.play();
      }

      const playlistEmbed = new MessageEmbed()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "Đã thêm playlist vào hàng chờ", iconURL: client.config.iconURL })
        .setThumbnail(res.tracks[0].thumbnail)
        .setDescription(`[${res.playlist.name}](${rawQuery})`)
        .addFields(
          {
            name: "Số bài",
            value: `\`${res.tracks.length}\` bài hát`,
            inline: true,
          },
          {
            name: "Tổng thời lượng",
            value: `\`${client.ms(res.playlist.duration, {
              colonNotation: true,
              secondsDecimalDigits: 0,
            })}\``,
            inline: true,
          }
        );

      await interaction.editReply({ embeds: [playlistEmbed] }).catch(() => {});
    }

    if (ret) setTimeout(() => ret.delete().catch(() => {}), 20000);
    return ret;
  });

module.exports = command;
