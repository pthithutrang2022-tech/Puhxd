const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("bo-loc")
  .setDescription("Thêm hoặc xóa hiệu ứng âm thanh")
  .addStringOption((option) =>
    option
      .setName("hieu-ung")
      .setDescription("Hiệu ứng muốn áp dụng")
      .setRequired(true)
      .addChoices(
        { name: "Nightcore", value: "nightcore" },
        { name: "BassBoost (Tăng bass)", value: "bassboost" },
        { name: "Vaporwave", value: "vaporwave" },
        { name: "Pop", value: "pop" },
        { name: "Soft (Nhẹ nhàng)", value: "soft" },
        { name: "Treblebass", value: "treblebass" },
        { name: "8D (Âm thanh 8 chiều)", value: "eightD" },
        { name: "Karaoke", value: "karaoke" },
        { name: "Vibrato", value: "vibrato" },
        { name: "Tremolo", value: "tremolo" },
        { name: "Đặt lại (Tắt tất cả)", value: "off" }
      )
  )
  .setRun(async (client, interaction) => {
    const args = interaction.options.getString("hieu-ung");
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có nhạc đang phát.")],
        ephemeral: true,
      });
    }

    const filtersEmbed = new MessageEmbed().setColor(client.config.embedColor);

    if (args === "nightcore") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Nightcore** đã bật!");
      player.nightcore = true;
    } else if (args === "bassboost") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **BassBoost** đã bật!");
      player.bassboost = true;
    } else if (args === "vaporwave") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Vaporwave** đã bật!");
      player.vaporwave = true;
    } else if (args === "pop") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Pop** đã bật!");
      player.pop = true;
    } else if (args === "soft") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Soft** đã bật!");
      player.soft = true;
    } else if (args === "treblebass") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Treblebass** đã bật!");
      player.treblebass = true;
    } else if (args === "eightD") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **8D** đã bật!");
      player.eightD = true;
    } else if (args === "karaoke") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Karaoke** đã bật!");
      player.karaoke = true;
    } else if (args === "vibrato") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Vibrato** đã bật!");
      player.vibrato = true;
    } else if (args === "tremolo") {
      filtersEmbed.setDescription("✅ | Hiệu ứng **Tremolo** đã bật!");
      player.tremolo = true;
    } else if (args === "off") {
      filtersEmbed.setDescription("✅ | Đã tắt tất cả hiệu ứng âm thanh!");
      player.reset();
    } else {
      filtersEmbed.setDescription("❌ | Hiệu ứng không hợp lệ!");
    }

    return interaction.reply({ embeds: [filtersEmbed] });
  });

module.exports = command;
