const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
  .setName("tiep-tuc")
  .setDescription("Tiếp tục phát bài hát đang tạm dừng")
  .setRun(async (client, interaction) => {
    const channel = await client.getChannel(client, interaction);
    if (!channel) return;

    const player = client.manager?.players.get(interaction.guild.id);
    if (!player) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Không có bài hát nào đang phát.")],
        ephemeral: true,
      });
    }

    if (!player.paused) {
      return interaction.reply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("Bài hát hiện tại đã đang phát rồi!")],
        ephemeral: true,
      });
    }

    player.pause(false);
    return interaction.reply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription("⏯ | **Đã tiếp tục phát!**"),
      ],
    });
  });

module.exports = command;
