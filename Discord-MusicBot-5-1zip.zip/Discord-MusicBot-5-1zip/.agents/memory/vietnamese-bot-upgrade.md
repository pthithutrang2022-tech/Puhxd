---
name: Vietnamese Discord Music Bot upgrade
description: Full production upgrade — Spotify removed, all Vietnamese, multi-platform support, clean deps
---

## Key decisions

**Command renames (Vietnamese transliteration, no diacritics):**
- play → phat, skip → bo-qua, stop → dung, pause → tam-dung, resume → tiep-tuc
- queue → hang-cho, loop → lap-lai, loopq → lap-hang-cho, shuffle → xao-tron
- volume → am-luong, filters → bo-loc, nowplaying → dang-phat, previous → truoc-do
- replay → phat-lai, save → luu, search → tim-kiem, seek → tua, skipto → bo-qua-den
- move → di-chuyen, remove → xoa-bai, clear → xoa-hang-cho, clean → don-dep
- lyrics → loi-bai-hat, stats → thong-ke, summon → trieu-hoi, guildleave → roi-may-chu
- autoleave → tu-roi, autopause → tu-tam-dung, autoqueue → tu-hang-cho, 247 → che-do-247
- invite → moi, help → tro-giup, reload → tai-lai, ping → ping (unchanged)
- context menu: "Play Song" → "Phát bài hát này"

**Smart search prefix:** Text queries use `ytmsearch:` prefix; URLs pass through directly to Lavalink.
- Fallback chain: ytmsearch → ytsearch → URL path extraction for Apple Music/Deezer

**seek.js:** Inline time parser (parseTime function) replaces the `ms` npm package. Supports: `1h 30m`, `2h`, `80m`, `53s`, `1:30`, `1:30:00`.

**packages removed:** `better-erela.js-spotify`, `discord-together`, `systeminformation`, `os` (built-in), `node-fetch` dashboard deps. `jsoning` kept (database). `express`+ecosystem kept (api module always required).

**interactionCreate.js:** autocomplete checks `interaction.commandName === "phat"` (not "play").

**Why:** User requested full Vietnamese translation and Spotify removal with multi-platform support.
